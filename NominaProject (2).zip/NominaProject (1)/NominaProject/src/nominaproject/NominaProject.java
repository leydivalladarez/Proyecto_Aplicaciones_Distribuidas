package nominaproject;

import com.nominaproject.view.NominaForm;

public class NominaProject {
    public static void main(String[] args) {
        NominaForm nominaForm = new NominaForm();
        nominaForm.setVisible(true);
    }
}
